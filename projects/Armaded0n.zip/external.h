#if !defined FUNCTION_H
#define FUNCTION_H



#endif


extern void option1();
extern HWND hWndMain;
extern HWND hWndLogin;