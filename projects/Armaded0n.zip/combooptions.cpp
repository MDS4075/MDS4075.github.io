#include "stdafx.h"
#include "external.h"
//#include "combooptions.h"
//#include "Win32Lesson1.cpp"


//HWND hWndMain;

void option(){

	ShowWindow(hWndMain, SW_HIDE);
	_sleep(1000);
	ShowWindow(hWndMain, SW_SHOW);
}