#include "stdafx.h"
#include "Resource.h"
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <process.h>
using namespace std;

TCHAR textbox;

void option1();
void option2();
void option3();
void option4();
void voidDelayM();
void voidDelayS();
void  TOne( void *arg );
void  TTwo( void *arg );
void  NoFuck( void *arg );
HWND hWndMain;
HWND hWndLogin;
HWND hWndBlack;

//void option1();



#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;	// current instance



TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
TCHAR szWindowClass2[MAX_LOADSTRING];			// the main window class name
TCHAR szWindowClass3[MAX_LOADSTRING];			// the main window class name				

TCHAR szExistingFile[_MAX_PATH] = _T("Armaded0n");

// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);


BOOL				InitInstance(HINSTANCE, int);

LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	WndProc2(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	WndProc3(HWND, UINT, WPARAM, LPARAM);

INT_PTR CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK	Features(HWND, UINT, WPARAM, LPARAM);


int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;
	

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_WIN32LESSON1, szWindowClass, MAX_LOADSTRING);
	LoadString(hInstance, IDC_WIN32LESSON1, szWindowClass2, MAX_LOADSTRING);
	//LoadString(hInstance, IDC_WIN32LESSON1, szWindowClass3, MAX_LOADSTRING);

	//MyRegisterClass(hInstance);

	WNDCLASSEX wcex;
	WNDCLASSEX wcex2;
	WNDCLASSEX wcex3;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WIN32LESSON1));
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW);
	wcex.lpszMenuName	= MAKEINTRESOURCE(IDC_WIN32LESSON1);
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	wcex2.cbSize = sizeof(WNDCLASSEX);

	wcex2.style			= CS_HREDRAW | CS_VREDRAW;
	wcex2.lpfnWndProc	= WndProc2;
	wcex2.cbClsExtra		= 0;
	wcex2.cbWndExtra		= 0;
	wcex2.hInstance		= hInstance;
	wcex2.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WIN32LESSON1));
	wcex2.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex2.hbrBackground	= (HBRUSH)(COLOR_WINDOW);
	wcex2.lpszMenuName	= NULL; 
	wcex2.lpszClassName	= _T("Login");
	wcex2.hIconSm		= LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

	wcex3.cbSize = sizeof(WNDCLASSEX);

	wcex3.style			= CS_HREDRAW | CS_VREDRAW;
	wcex3.lpfnWndProc	= WndProc3;
	wcex3.cbClsExtra		= 0;
	wcex3.cbWndExtra		= 0;
	wcex3.hInstance		= hInstance;
	wcex3.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_TROLL));
	wcex3.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex3.hbrBackground	= (HBRUSH)(COLOR_WINDOW);
	wcex3.lpszMenuName	= NULL; 
	wcex3.lpszClassName	= _T("Black");
	wcex3.hIconSm		= LoadIcon(wcex3.hInstance, MAKEINTRESOURCE(IDI_TROLL));

	//return RegisterClassEx(&wcex2);
	if (!RegisterClassEx (&wcex))
        return 1;

	if (!RegisterClassEx (&wcex2))
        return 2;

	if (!RegisterClassEx (&wcex3))
        return 3;


//////////////////////////////////////////////////////////////////////////
////
////  CREATE WINDOWS
////	
	hWndBlack = CreateWindow(_T("Black"), _T("Microsoft Office Activation"), WS_OVERLAPPED | WS_MINIMIZEBOX | WS_SYSMENU | WS_POPUP, 
   CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	hWndLogin = CreateWindow(_T("Login"), _T("Armaged0n Login"), WS_SYSMENU, 
   CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	hWndMain = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPED | WS_MINIMIZEBOX | WS_SYSMENU, 
   CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	

	SetWindowPos(hWndLogin, HWND_TOP, 0, 0, 240, 90, SWP_NOMOVE);
	SetWindowPos(hWndMain, HWND_TOP, 0, 0, 250, 300, SWP_NOMOVE);
	SetWindowPos(hWndBlack, HWND_TOP, 0, 0, 1000000, 1000000, SWP_NOMOVE);
	//ShowWindow(hWndMain, nCmdShow);
	UpdateWindow(hWndMain);

	ShowWindow(hWndLogin, nCmdShow);
	UpdateWindow(hWndLogin);

	
	UpdateWindow(hWndBlack);
//////////////////////////////////////////////////////////////////////////
////
////  MESSAGE LOOP
////

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow))
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_WIN32LESSON1));

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0))
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
/*ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex3;
	

	wcex3.cbSize = sizeof(WNDCLASSEX);

	wcex3.style			= CS_HREDRAW | CS_VREDRAW;
	wcex3.lpfnWndProc	= WndProc;
	wcex3.cbClsExtra		= 0;
	wcex3.cbWndExtra		= 0;
	wcex3.hInstance		= hInstance;
	wcex3.hIcon			= LoadIcon(hInstance, MAKEINTRESOURCE(IDI_WIN32LESSON1));
	wcex3.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex3.hbrBackground	= (HBRUSH)(COLOR_WINDOW);
	wcex3.lpszMenuName	= MAKEINTRESOURCE(IDC_WIN32LESSON1);
	wcex3.lpszClassName	= szWindowClass;
	wcex3.hIconSm		= LoadIcon(wcex3.hInstance, MAKEINTRESOURCE(IDI_SMALL));
	return RegisterClassEx(&wcex3);
	//if (!RegisterClassEx (&wcex3))
     //   return 1;

	
}
*/




//
//   FUNCTION: InitInstance(HINSTANCE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;
   HWND hWndEdit;
   HWND hWnd2;
   hInst = hInstance;

  // hInst = hInstance; // Store instance handle in our global variable

  // hWnd2 = CreateWindow(szWindowClass2, szTitle2, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	//hWnd2 = CreateWindow(szWindowClass2, szTitle2, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance2, NULL);

	///hWnd2 = CreateWindow(szWindowClass2, szTitle, WS_OVERLAPPED | WS_MINIMIZEBOX | WS_SYSMENU, 
   ///CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	///hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPED | WS_MINIMIZEBOX | WS_SYSMENU, 
  /// CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

    // hWnd = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW, 
     // CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);

	 

	 
	

	 SetWindowPos(hWnd, HWND_TOP, 0, 0, 300, 400, SWP_NOMOVE);

	ShowWindow(hWnd2, nCmdShow);
	UpdateWindow(hWnd2);



   if (!hWnd)
   {
      return FALSE;
   }

   

    ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);

	ShowWindow(hWnd2, nCmdShow);
    UpdateWindow(hWnd2);

   return TRUE;
   
}




//
//  FUNCTION: WndProc(HWND, UINT, WPARAM, LPARAM)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
LPRECT window;
TCHAR DelayM[_MAX_PATH];
TCHAR DelayS[_MAX_PATH];
TCHAR TDelayS[MAX_PATH];
TCHAR TDelayM[MAX_PATH];
int oDelayS;
int oDelayM;
int iDelayS;
int iDelayM;
int LengthS;
int LengthM;
int TotalDelay;
HWND hWndButton1;
HWND hWndButton2;
HWND DelayMBox;
HWND DelaySBox;
HWND label;
HWND hwnd;
HWND hWndDisplay;
HWND hWndComboBox;
HFONT unifont = CreateFont( -15, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Latin") 
						);
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;
	string _T(myString);
	LPWSTR pszText[10];
	switch (message)
	{


	case WM_CREATE: 
		{
			
			HFONT combofont = CreateFont( -15, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Verdana") 
						); 


			const LPWSTR ComboBoxItems[] = { 

				
				
				_T("Please Select an Option"), _T("Hide"), _T("Classic Office Spam"),
                                    _T("App Freeze & Burn"), _T("Messagebox Office Spam") };

		
		
		hWndComboBox =	CreateWindow(_T("COMBOBOX"),
             NULL,
             WS_CHILD | CBS_DROPDOWNLIST | WS_VISIBLE | WS_TABSTOP,
             2, 35, 200, 60,
             hWnd,
             (HMENU) C_MAINOPTION,
             hInst,
             NULL);
		SendMessage(hWndComboBox, WM_SETFONT, (WPARAM)unifont, 0);
		//60, 62, 136, 60, default combobox		
		
		
		SendMessage(hWndComboBox,
                        CB_ADDSTRING,
                        0,
                        reinterpret_cast<LPARAM>((LPCTSTR)ComboBoxItems[0]));

		SendMessage(hWndComboBox,
                        CB_ADDSTRING,
                        0,
                        reinterpret_cast<LPARAM>((LPCTSTR)ComboBoxItems[1]));
            SendMessage(hWndComboBox,
                        CB_ADDSTRING,
                        0,
                        reinterpret_cast<LPARAM>((LPCTSTR)ComboBoxItems[2]));
            SendMessage(hWndComboBox,
                        CB_ADDSTRING,
                        0,
                        reinterpret_cast<LPARAM>((LPCTSTR)ComboBoxItems[3]));
            SendMessage(hWndComboBox,
                        CB_ADDSTRING,
                        0,
                        reinterpret_cast<LPARAM>((LPCTSTR)ComboBoxItems[4]));

			SendMessage(hWndComboBox, CB_SETCURSEL, 0, 0);
			

			};
			
			hWndButton1 =  CreateWindowA("BUTTON", "Start",
                WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
				150, 196, 80, 40, hWnd, (HMENU) B_MAINSTART, NULL, NULL);

			hWndButton2 =  CreateWindowA("BUTTON", "Set",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
				180, 78, 40, 27, hWnd, (HMENU) B_MAINSET, NULL, NULL);


			DelaySBox = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(""),
                               WS_CHILD | WS_VISIBLE, 110, 80, 40,
                               25, hWnd, (HMENU) E_MAINDELAYM, NULL, NULL);

			DelayMBox = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(""),
                               WS_CHILD | WS_VISIBLE, 40, 80, 40,
                               25, hWnd, (HMENU) E_MAINDELAYS, NULL, NULL);
						

			
		SendMessage(hWndButton1, WM_SETFONT, (WPARAM)unifont, 0);
		SendMessage(hWndButton2, WM_SETFONT, (WPARAM)unifont, 0);
		SendMessage(DelayMBox, WM_SETFONT, (WPARAM)unifont, 0);
		SendMessage(DelaySBox, WM_SETFONT, (WPARAM)unifont, 0);


	case WM_COMMAND:
		switch (wParam){
		case 1: 
			{
				
				TCHAR tcInput [256];
				GetWindowText (GetDlgItem (hWnd, C_MAINOPTION), tcInput, 256);
				//::MessageBox(hWnd, tcInput , _T("Works!"), MB_OK);

				LRESULT nCurSel = SendMessage(hWndComboBox, CB_GETCURSEL, 0, 0);
				switch(nCurSel)
				{
					case 0:
						{
							
						}
					break;
					case 1:
						option1();
					break;
					case 2:
						option2();
					break;
					case 3:
						option3();
					break;
					case 4:
						option4();
					break;

				}
				
				TCHAR DelayM[_MAX_PATH];
				CHAR correct[] = ("Hello");
				CHAR cDelayM[MAX_PATH];
				HWND hEditWnd;
				HWND hDlg;
				GetWindowText(DelayMBox, DelayM, _MAX_PATH);
				wcstombs(cDelayM, DelayM, _MAX_PATH); 
			break;
			}
          
		case 2:
			{
			_sleep(10);
				
				GetWindowText(DelayMBox, DelayM, _MAX_PATH);
				GetWindowText(DelaySBox, DelayS, _MAX_PATH);

				
				//oDelayS = iDelayS;
				oDelayM = 0;
				iDelayS = 0;
				oDelayS = _tstoi(DelayS); //Convert DelayS to int i
				iDelayS = oDelayS;
				
				//oDelayS = 6;
				string test[MAX_PATH]; //Tempory to hold data 
				stringstream out; //Conversion part
				/*
				while(iDelayS >= 60)
				{
		///			::MessageBox(hWnd, _T("if statement working"), _T("Works!"), MB_OK);
					oDelayM = oDelayM + 1;
					iDelayS = iDelayS - 60;
				}
				out << iDelayS;
				test[MAX_PATH] = out.str();
				mbstowcs(TDelayS,test[MAX_PATH].c_str(),test[MAX_PATH].length()+1);
				*/
				CHAR cDelayM[MAX_PATH];
				CHAR cDelayS[MAX_PATH];

				//string test55 = cDelayM;
				
				//HWND hEditWnd;
				//HWND hDlg;
				//MultiByteToWideChar(CP_ACP, 0, test, -1,  Tother, 150);
				
				wcstombs(cDelayM, DelayM, _MAX_PATH); 
				wcstombs(cDelayS, DelayS, _MAX_PATH); 
		///		//::MessageBox(hWnd, DelayM, _T("Works!"), MB_OK);
		///		//::MessageBox(hWnd, DelayS, _T("Works!"), MB_OK);
		///		//::MessageBox(hWnd, TDelayS, _T("Works!"), MB_OK);
				voidDelayS();
				voidDelayM();			
				

				//////////////////////////////
				if(iDelayM < 1)//No delay
				{
		///			::MessageBox(hWnd, _T("No delay"), _T("No delay"), MB_OK);
					LengthM = 0;

				}
				if(iDelayM >= 1 && iDelayM < 10)//1 charactor
				{
					LengthM = 1;

				}
				if(iDelayM >= 10 && iDelayM < 100)//2 charactor
				{
					LengthM = 2;

				}
				if(iDelayM >= 100 && iDelayM < 1000)//3 charactor
				{
					LengthM = 3;

				}
				if(iDelayM >= 1000 && iDelayM < 10000)//4 charactor
				{
					LengthM = 4;

				}
				//////////////////////////////////////////////
				///
				///other one sec.
				///

				if(iDelayS < 1)//No delay
				{
			///		::MessageBox(hWnd, _T("No delay"), _T("No delay"), MB_OK);
					LengthS = 0;

				}
				if(iDelayS >= 1 && iDelayS < 10)//1 charactor
				{
					LengthS = 1;

				}
				if(iDelayS >= 10 && iDelayS < 100)//2 charactor
				{
					LengthS = 2;

				}
				if(iDelayS >= 100 && iDelayS < 1000)//3 charactor
				{
					LengthS = 3;

				}
				
				TotalDelay = (iDelayM * 60000) + (iDelayS * 1000);
				GetClientRect(hWndMain, window);
				InvalidateRect(hWndMain, NULL, TRUE);
				break;
				}
			}
		

		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_FEATURES:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_FEATURESBOX), hWnd, Features);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;



	case WM_PAINT:
		RECT rect;
		hdc = BeginPaint(hWnd, &ps);
		GetClientRect(hWnd, &rect);
		SetBkMode( hdc, TRANSPARENT );
		

		SelectObject(hdc, CreateFont( -17, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("BankGothic Md BT")));//_T("Latin") 
					
		TextOut(hdc, 5, 0, _T("Welcome to Armaged0n "), 20);
		//Verdana			
		SelectObject(hdc, CreateFont( -14, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Latin")));

		TextOut(hdc, 0, 85, _T("Delay:"), 6);
		TextOut(hdc, 82, 86, _T("Min"), 3);
		TextOut(hdc, 152, 86, _T("Sec"), 3);

		if(iDelayM <=0 && iDelayS >= 1)
		{
			
			TextOut(hdc, 70, 150, TDelayS, LengthS );
			TextOut(hdc, 90, 150, _T("sec"), 3);
		}
		
		if(iDelayM >= 1 || iDelayS >= 1)
		{
			TextOut(hdc, 2, 150, _T("A delay of"), 10);

		}
		

		if(!iDelayM >= 1 && !iDelayS >= 1)
		{
		TextOut(hdc, 2, 150, _T("No delay"), 8);
		}

		if(iDelayM >= 1 && iDelayM <= 1)
		{
			if(iDelayS <= 0)
			{
				TextOut(hdc, 82, 150, _T("min"), 3);
			}
			TextOut(hdc, 135, 150, TDelayS, LengthS );
			if(!iDelayS <= 0)
			{
				TextOut(hdc, 154, 150, _T("sec"), 3);
				TextOut(hdc, 82, 150, _T("min and"), 7);

			}

		}
		if(iDelayM > 1 && iDelayM < 10)
		{
			if(iDelayS <= 0)
			{
				TextOut(hdc, 82, 150, _T("min"), 3);
			}
	//		TextOut(hdc, 82, 150, _T("mins and"), 8);
			TextOut(hdc, 135, 150, TDelayS, LengthS );
			if(!iDelayS <= 0)
			{
				TextOut(hdc, 154, 150, _T("sec"), 3);
				TextOut(hdc, 82, 150, _T("min and"), 7);

			}
		}
		if(iDelayM >= 10 && iDelayM < 100)
		{
			if(iDelayS <= 0)
			{
				TextOut(hdc, 91, 150, _T("min"), 3);
			}
	//		TextOut(hdc, 90, 150, _T("mins and"), 8);
			TextOut(hdc, 144, 150, TDelayS, LengthS );
			if(!iDelayS <= 0)
			{
				TextOut(hdc, 163, 150, _T("sec"), 3);
				TextOut(hdc, 91, 150, _T("min and"), 7);

			}
		}
		if(iDelayM >= 100 && iDelayM < 1000)
		{
			if(iDelayS <= 0)
			{
				TextOut(hdc, 98, 150, _T("min"), 3);
			}
	//		TextOut(hdc, 98, 150, _T("mins and"), 8);
			TextOut(hdc, 151, 150, TDelayS, LengthS );
			if(!iDelayS <= 0)
			{
				TextOut(hdc, 170, 150, _T("sec"), 3);
				TextOut(hdc, 98, 150, _T("min and"), 7);

			}

		}
		if(iDelayM >= 1000 && iDelayM < 10000)//4 charactor
		{
			if(iDelayS <= 0)
			{
				TextOut(hdc, 105, 150, _T("min"), 3);
			}
	//		TextOut(hdc, 106, 150, _T("mins and"), 8);
			TextOut(hdc, 158, 150, TDelayS, LengthS );
			if(!iDelayS <= 0)
			{
				TextOut(hdc, 177, 150, _T("sec"), 3);
				TextOut(hdc, 105, 150, _T("min and"), 7);

			}
		}
		//TextOut(hdc, 110, 150, _T("minutes and"), 10);
		TextOut(hdc, 70, 150, TDelayM, LengthM );
		
		// TODO: Add any drawing code here...
		
		EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
			PostQuitMessage(0);
		break;


	

	/*
    switch (wParam) {
        case _T('a'):
        {
            ::MessageBox(hWnd, _T("a") , _T("Key Pressed"), MB_OK);
            break;
        }
        case _T('A'):
        {
            ::MessageBox(hWnd, _T("A") , _T("Key Pressed"), MB_HELP);
            break;
        }
    }
	
    break;
	*/
	

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}


///////////////////////////////////////////////////////////////
///
///Defining before hWndLogin Proc
///
LRESULT CALLBACK SubClassEdit(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam);
WNDPROC OldtextBox2;
HWND TextBox2;
HFONT Login = CreateFont( -13, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Latin") 
						); 

LRESULT CALLBACK WndProc2(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	

	int wmId, wmEvent;
	
	
	
	PAINTSTRUCT ps;
	HDC hdc;
	string _T(myString);
	LPWSTR pszText[10];
	switch (message)
	{


	case WM_CREATE: 
		{
			HWND TextBox1;
			
			HFONT combofont = CreateFont( -15, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Verdana") 
						); 
			SendMessage(hWndButton1, WM_SETFONT, (WPARAM)Login, 0);
			SendMessage(TextBox1, WM_SETFONT, (WPARAM)unifont, 0);


			hWndButton1 =  CreateWindowA("BUTTON", "Login",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
				179, 13, 40, 25, hWnd, (HMENU) 1, NULL, NULL);
			SendMessage(hWndButton1, WM_SETFONT, (WPARAM)Login, 0);


			TextBox2 = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(""),
                               WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_PASSWORD, 70, 13, 105,
                               25, hWnd, (HMENU) 12, NULL, NULL);
						
			
			
			OldtextBox2 = (WNDPROC) SetWindowLong(TextBox2, GWL_WNDPROC,(LONG)SubClassEdit);
			
			
			
		
		}

	case WM_COMMAND:
		
		
	//break;



		switch (wParam){
		case 1: 
			{
				//SendMessage(hWndComboBox, CB_SHOWDROPDOWN, TRUE, 0);

				//::MessageBox(hWnd, _T("YOU ARE BOSS MARC SANDERSON!!!!!!") , _T("Works!"), MB_OK);
				TCHAR tcInput [256];
				GetWindowText (GetDlgItem (hWnd, 5), tcInput, 256);
				//::MessageBox(hWnd, tcInput , _T("Works!"), MB_OK)
				TCHAR userName[_MAX_PATH];
				CHAR correct[] = ("TrollKing");
				CHAR cusername[MAX_PATH];
				HWND hEditWnd;
				HWND hDlg;
				GetWindowText(TextBox2, userName, _MAX_PATH);
				wcstombs(cusername, userName, _MAX_PATH); 
				

				if(strcmp (cusername, correct) == 0)
				{
					ShowWindow(hWndLogin, SW_HIDE);
					ShowWindow(hWndMain, SW_SHOW);
				}
				else
				{
					::MessageBox(hWndLogin, _T("That Is Not a Valid Password :P"), _T("Incorrect Password!"), MB_ICONHAND);
					SetFocus(TextBox2);
					SetWindowText(TextBox2, _T(""));
				}
				break;
			}

	/*	case WM_KEYUP:
			{	
				switch (wParam) 
				{
						case VK_ESCAPE:
							{
								::MessageBox(hWnd, _T("Esc") , _T("Key Released"), MB_OK);
								break;
							}
				}		
				break;
			}	
		*/
		
		}
		

		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_FEATURES:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_FEATURESBOX), hWnd, Features);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;



	case WM_PAINT:
		RECT rect;
		hdc = BeginPaint(hWnd, &ps);
		GetClientRect(hWnd, &rect);
		SetFocus(TextBox2);
		SetBkMode( hdc, TRANSPARENT );
		
		SelectObject(hdc, CreateFont( -13, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Latin") 
						) ); 
		

					//Verdana

		
		


		// TODO: Add any drawing code here...
		TextOut(hdc, 4, 18, _T("Password: "), 9);
		EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

LRESULT CALLBACK WndProc3(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	
	
	
	PAINTSTRUCT ps;
	HDC hdc;
	string _T(myString);
	LPWSTR pszText[10];
	switch (message)
	{


	case WM_CREATE: 
		{
			HWND TextBox1;
			
			HFONT combofont = CreateFont( -15, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Verdana") 
						); 
			SendMessage(hWndButton1, WM_SETFONT, (WPARAM)Login, 0);
			SendMessage(TextBox1, WM_SETFONT, (WPARAM)unifont, 0);


			hWndButton1 =  CreateWindowA("BUTTON", "Login",
                WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
				179, 13, 40, 25, hWnd, (HMENU) 1, NULL, NULL);
			SendMessage(hWndButton1, WM_SETFONT, (WPARAM)Login, 0);


			TextBox2 = CreateWindowEx(WS_EX_CLIENTEDGE, TEXT("EDIT"), TEXT(""),
                               WS_CHILD | WS_VISIBLE | ES_AUTOHSCROLL | ES_PASSWORD, 70, 13, 105,
                               25, hWnd, (HMENU) 12, NULL, NULL);
						
			
			
			OldtextBox2 = (WNDPROC) SetWindowLong(TextBox2, GWL_WNDPROC,(LONG)SubClassEdit);
			
			
			
		
		}

	case WM_COMMAND:
		
		
	//break;



		switch (wParam){
		case 1: 
			{
				//SendMessage(hWndComboBox, CB_SHOWDROPDOWN, TRUE, 0);

				//::MessageBox(hWnd, _T("YOU ARE BOSS MARC SANDERSON!!!!!!") , _T("Works!"), MB_OK);
				TCHAR tcInput [256];
				GetWindowText (GetDlgItem (hWnd, 5), tcInput, 256);
				//::MessageBox(hWnd, tcInput , _T("Works!"), MB_OK)
				TCHAR userName[_MAX_PATH];
				CHAR correct[] = ("TrollKing");
				CHAR cusername[MAX_PATH];
				HWND hEditWnd;
				HWND hDlg;
				GetWindowText(TextBox2, userName, _MAX_PATH);
				wcstombs(cusername, userName, _MAX_PATH); 
				

				if(strcmp (cusername, correct) == 0)
				{
					ShowWindow(hWndLogin, SW_HIDE);
					ShowWindow(hWndMain, SW_SHOW);
				}
				else
				{
					::MessageBox(hWndLogin, _T("That is not a valid password :P"), _T("Incorrect Password!"), MB_OK);
					SetFocus(TextBox2);
					SetWindowText(TextBox2, _T(""));
				}
				break;
			}

	/*	case WM_KEYUP:
			{	
				switch (wParam) 
				{
						case VK_ESCAPE:
							{
								::MessageBox(hWnd, _T("Esc") , _T("Key Released"), MB_OK);
								break;
							}
				}		
				break;
			}	
		*/
		
		}
		

		wmId    = LOWORD(wParam);
		wmEvent = HIWORD(wParam);
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_FEATURES:
			DialogBox(hInst, MAKEINTRESOURCE(IDD_FEATURESBOX), hWnd, Features);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;



	case WM_PAINT:
		RECT rect;
		hdc = BeginPaint(hWnd, &ps);
		GetClientRect(hWnd, &rect);
		SetFocus(TextBox2);
		SetBkMode( hdc, TRANSPARENT );
		
		SelectObject(hdc, CreateFont( -13, 0, 0, 0, 
						 FW_NORMAL, FALSE, FALSE,
						 FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, 
						 CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
						 VARIABLE_PITCH, _T("Latin") 
						) ); 
		

					//Verdana

		
		


		// TODO: Add any drawing code here...
		TextOut(hdc, 4, 18, _T("Password: "), 9);
		EndPaint(hWnd, &ps);
		break;
		case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}
			

// Message handler for features box.
INT_PTR CALLBACK Features(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

LRESULT CALLBACK SubClassEdit(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam){
	switch (message){
		case WM_GETDLGCODE:
			return (DLGC_WANTALLKEYS | CallWindowProc(OldtextBox2, hwnd, message,wParam, lParam));
		case WM_CHAR:
			//Process this message to avoid message beeps.
			if ((wParam == VK_RETURN) || (wParam == VK_TAB))
				return 0;
			else
				return (CallWindowProc(OldtextBox2, hwnd,message, wParam, lParam));
		case WM_KEYDOWN:
			// This bit gets the return or tab  key from the edit box and moves focus to next edit box
			if ((wParam== VK_RETURN ) || (wParam == VK_TAB)){
			//SetFocus(hWndButton1);
			TCHAR userName[_MAX_PATH];
				CHAR correct[] = ("TrollKing");
				CHAR cusername[MAX_PATH];
				HWND hEditWnd;
				HWND hDlg;
				GetWindowText(TextBox2, userName, _MAX_PATH);
				wcstombs(cusername, userName,_MAX_PATH); 


				if(strcmp (cusername, correct) == 0)
				{
					ShowWindow(hWndLogin, SW_HIDE);
					ShowWindow(hWndMain, SW_SHOW);
				}
				else
				{
					::MessageBox(hWndLogin, _T("That Is Not a Valid Password :P"), _T("Incorrect Password!"), MB_ICONHAND);
					SetFocus(TextBox2);
					SetWindowText(TextBox2, _T(""));
				}
			return FALSE;
			}
	}
	return CallWindowProc(OldtextBox2,hwnd,message,wParam,lParam);
}



void option1(){

	//::MessageBox(hWndLogin, _T("Option 1"), _T("Optionz"), MB_OK);
	ShowWindow(hWndMain,SW_HIDE);
	_sleep(TotalDelay);
	ShowWindow(hWndMain,SW_SHOW);
}

void option2(){
	ShowWindow(hWndMain,SW_HIDE);
	_sleep(TotalDelay);
	_beginthread( TTwo, 0, (void*)12 );
}

void option3(){
	ShowWindow(hWndMain,SW_HIDE);
	_sleep(TotalDelay);
	ShowWindow(hWndBlack,SW_SHOW);
	_beginthread( TOne, 0, (void*)13 );
	_beginthread( TOne, 0, (void*)13 );
	_beginthread( TOne, 0, (void*)13 );
	_beginthread( TOne, 0, (void*)13 );
	_beginthread( TOne, 0, (void*)13 );
	_beginthread( TOne, 0, (void*)13 );
	_beginthread( TOne, 0, (void*)13 );
}

void option4(){
	ShowWindow(hWndMain,SW_HIDE);
	_sleep(TotalDelay);
	::MessageBox(hWndBlack, _T("Cannot start Microsoft Office Outlook. Cannot start the Outlook window."), _T("Microsoft Office Outlook"), MB_ICONHAND);
	_beginthread( TTwo, 0, (void*)12 );
}

void voidDelayM(){
					
				
				
				
				iDelayM = _tstoi(DelayM) + oDelayM; //Convert DelayS to int i and add oDelayM

				string test2[MAX_PATH]; //Tempory to hold data 
				stringstream out; //Conversion part
				out << iDelayM;
				test2[MAX_PATH] = out.str();
				mbstowcs(TDelayM,test2[MAX_PATH].c_str(),test2[MAX_PATH].length()+1);
				
			//	CHAR cDelayM[MAX_PATH];
				//CHAR cDelayS[MAX_PATH];

				//MultiByteToWideChar(CP_ACP, 0, test, -1,  Tother, 150);
				
				

				
	///			::MessageBox(hWndMain, TDelayM, _T("Works!"), MB_OK);
				

}

void voidDelayS(){
				string test[MAX_PATH]; //Tempory to hold data 
				stringstream out;
					
				while(iDelayS >= 60)
				{
		///			::MessageBox(hWnd, _T("if statement working"), _T("Works!"), MB_OK);
					oDelayM = oDelayM + 1;
					iDelayS = iDelayS - 60;
				}
				out << iDelayS;
				test[MAX_PATH] = out.str();
				mbstowcs(TDelayS,test[MAX_PATH].c_str(),test[MAX_PATH].length()+1);
				

}


void  TOne( void *arg )
{
    while(1);
}

void  TTwo( void *arg )
{
	while(1){
    
	STARTUPINFO si = {};
    si.cb = sizeof si;

    PROCESS_INFORMATION pi = {};
    TCHAR* target = _T("C:\\Program Files\\Microsoft Office\\Office14\\EXCEL.exe");

    if ( !CreateProcess(target, 0, 0, FALSE, 0, 0, 0, 0, &si, &pi) )
    {
        
    }
	  
    si.cb = sizeof si;

   
    target = _T("C:\\Program Files\\Microsoft Office\\Office14\\WINWORD.exe");

    if ( !CreateProcess(target, 0, 0, FALSE, 0, 0, 0, 0, &si, &pi) )
    {
        
    }
	
    si.cb = sizeof si;

    
    target = _T("C:\\Program Files\\Microsoft Office\\Office14\\ONENOTE.exe");

    if ( !CreateProcess(target, 0, 0, FALSE, 0, 0, 0, 0, &si, &pi) )
    {
        
    }

    si.cb = sizeof si;

   
    target = _T("C:\\Program Files\\Microsoft Office\\Office14\\POWERPNT.exe");

    if ( !CreateProcess(target, 0, 0, FALSE, 0, 0, 0, 0, &si, &pi) )
    {
        
    }

	}
}


void  NoFuck( void *arg ){



}